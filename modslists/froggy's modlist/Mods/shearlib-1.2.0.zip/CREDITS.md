This mod would have not been possible without the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Catasteroid** for providing the original source code!

### Testing, Feedback and Bugreporting

* **Sekelsta**: for Helping debugging the lastShearTime bug

### Translators

* English advisors: **Ashantin**, **jjallie1**
* Czech: **DejFidOFF**
* French: **Wailwolf**
* German: **Tels**, **Phiwa**
* Japanese: **Macoto Hino**
* Russian: **Morok**
* Spanish: **Ruddi**
* Ukrainian: **DeanBro**

