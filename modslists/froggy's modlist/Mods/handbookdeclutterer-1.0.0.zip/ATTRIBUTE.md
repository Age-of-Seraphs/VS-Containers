This mod utilizes some files from DanaCraluminum's Fix Handbook Clutter which can be found at 
https://github.com/Craluminum-Mods/FixHandbookClutter
