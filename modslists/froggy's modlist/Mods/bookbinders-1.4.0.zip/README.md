# Bookbinders

"Craft, trade and find new books and tools."

This Vintage Story mod adds books and tools related to book binding.

## Tweaks

* Ink & Quill is crafted from quartz
* Book binding requires flax twine

## New Book Colors & Styles

Craft new book colors like dark blue or white books.

## Tools of the Trade

* A new "bone folder" tool

## Compatibility With Other Mods

* Tailor's Delight - with TD, book crafting needs awls, too
* Book traders - The trader buys some of the new books

We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/bookbinders)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_bookbinders/-/releases)

# Installation

This mod should work in existing worlds. If in doubt, please create a new world.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

When you remove the mod, the new items and blocks will left behind as white question mark blocks.
You need to remove these in creative mode.

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

