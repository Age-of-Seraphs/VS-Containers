# Vintage Story Player List

Shows a player list when you hold down tab, similar to Minecraft. Keybind is configurable.
