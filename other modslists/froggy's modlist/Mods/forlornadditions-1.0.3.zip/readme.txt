Ukrainian localization done by justOmi
