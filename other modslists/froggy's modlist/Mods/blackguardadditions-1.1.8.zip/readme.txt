Ukrainian localization done by justOmi
Embroidered Blackguard banner created by Jakob von Walser
